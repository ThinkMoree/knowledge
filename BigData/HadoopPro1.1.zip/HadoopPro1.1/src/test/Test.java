package test;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;

import util.PrintJobInfo;
import web.hadoop.WordCount;

public class Test {

	/**
	 * @param args
	 * @throws InterruptedException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, IOException, InterruptedException {
		WordCount c=new WordCount();
		String jobName="wordCountJob";
		String input="hdfs://192.168.128.138:9000/user/hadoop/input/";
		String output="hdfs://192.168.128.138:9000/user/hadoop/output/test";
		Configuration conf=c.initJob(new String[]{jobName,input,output});
		new Thread(new PrintJobInfo(conf,50)).start();
		c.runJob();
		
	}

}
