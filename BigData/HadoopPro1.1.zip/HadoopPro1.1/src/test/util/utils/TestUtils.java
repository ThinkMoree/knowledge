package test.util.utils;

import util.Utils;

public class TestUtils {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		testIsPathExists();
	}
	
	public static void testIsPathExists(){
		
		String path="hdfs://"+Utils.HADOOP_HOST+":9000/user/hadoop/input/start-all";
		boolean flag=Utils.isPathExists(path);
		System.out.println(path+" exits?"+flag);
	}

}
