package test;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;

import util.RunJobThread;
import util.Utils;
import web.hadoop.WordCount;

public class TestUtilsGetProgess {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws InterruptedException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		WordCount c=new WordCount();
		String jobName="wordCountJob";
		String input="hdfs://192.168.128.138:9000/user/hadoop/input/";
		String output="hdfs://192.168.128.138:9000/user/hadoop/output/test";
		Configuration conf=c.initJob(new String[]{jobName,input,output});

		new Thread(new RunJobThread(new String[]{jobName,input,output})).start();
	
		
		float[] progress=new float[2];
		for(int i=0;i<40;i++){
			Configuration conf1=new Configuration();
			conf1.set("mapred.job.tracker", Utils.JOBTRACKER);
			
			System.out.println("map:"+progress[0]+",reduce:"+progress[1]);
			Thread.sleep(4000);
			progress=Utils.getMapReduceProgess(conf1); 
		}
	}
	

}
