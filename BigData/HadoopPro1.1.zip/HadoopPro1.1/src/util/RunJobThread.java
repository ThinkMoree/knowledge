package util;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;

import web.hadoop.WordCount;

public class RunJobThread implements Runnable {
	
	private String[] args;
	public RunJobThread(String[] args){
		this.args=args;
	}
	
	public void run() {
		WordCount wc=new WordCount();
		Configuration conf=new Configuration();
	 	try {
			conf=wc.initJob(args);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	 	try {
	 		Utils.conf=conf;
	 		Utils.JOB_START_TIME=System.currentTimeMillis();
			wc.runJob();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
