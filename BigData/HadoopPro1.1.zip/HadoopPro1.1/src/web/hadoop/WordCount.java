package web.hadoop;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


import util.Utils;


public class WordCount {
	
	private Job job;
	public Configuration initJob(String[] args) throws IOException{
		Configuration conf=new Configuration();
		conf.set("mapred.job.tracker", Utils.JOBTRACKER);
		job=new Job(conf,args[0]);
		job.setJarByClass(WordCount.class);  
		job.setMapperClass(  WordCountMapper.class);  
		job.setMapOutputKeyClass(Text.class);  
		job.setMapOutputValueClass(IntWritable.class);  
		job.setNumReduceTasks(1);  

		job.setReducerClass( WordCountReducer.class);  
		job.setOutputKeyClass(NullWritable.class);  
		job.setOutputValueClass(Text.class);  
          
        FileInputFormat.setInputPaths(job, new Path(args[1]));  
        FileOutputFormat.setOutputPath(job, new Path(args[2]));  
        
		return conf;
	}
	
	public void runJob() throws IOException, ClassNotFoundException, InterruptedException{
		
        job.waitForCompletion(true);
		
	}
	
	
}
